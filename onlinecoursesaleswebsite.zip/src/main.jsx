// import React from 'react';
// import ReactDOM from 'react-dom/client';
// // import App from './App.jsx';
// import './App.css';
// import './index.css';
// import {RouterProvider, createBrowserRouter} from 'react-router-dom';
// // import {lazy} from 'react';
// // const Layout = lazy(() => import('./Layout.jsx'));
// // const Home = lazy(() => import('./componentes/Pages/Home/Home.jsx'));
// // const Carts = lazy(() => import('./componentes/Pages/Carts/Carts.jsx'));
// // const FullstackDevelopment = lazy(() =>
// //   import('./componentes/Pages/Courses/FullstackDevelopment.jsx'),
// // );
// // const AndroidDevelopment = lazy(() =>
// //   import('./componentes/Pages/Courses/AndroidDevelopment.jsx'),
// // );
// // const DevopsDevelopment = lazy(() =>
// //   import('./componentes/Pages/Courses/DevopsDevelopment.jsx'),
// // );
// // const WebDevelopment = lazy(() =>
// //   import('./componentes/Pages/Courses/WebDevelopment.jsx'),
// // );
// // const AiDevelopments = lazy(() =>
// //   import('./componentes/Pages/Courses/AiDevelopments.jsx'),
// // );

// import Layout from './Layout.jsx';
// import Home from './componentes/Pages/Home/Home.jsx';
// import Carts from './componentes/Pages/Carts/Carts.jsx';
// import FullstackDevelopment from './componentes/Pages/Courses/FullstackDevelopment.jsx';
// import AndroidDevelopment from './componentes/Pages/Courses/AndroidDevelopment.jsx';
// import DevopsDevelopment from './componentes/Pages/Courses/DevopsDevelopment.jsx';
// import AiDevelopments from './componentes/Pages/Courses/AiDevelopments.jsx';
// import WebDevelopment from './componentes/Pages/Courses/WebDevelopment.jsx';
// const router = createBrowserRouter([
//   {
//     path: '/',
//     element: <Layout />,
//     children: [
//       {
//         path: '/',
//         element: <Home />,
//       },
//       {
//         // path:'courses',
//         path: '/webdevelopment',
//         element: <WebDevelopment />,
//       },

//       {
//         path: '/androiddevelopment',
//         element: <AndroidDevelopment />,
//       },
//       {
//         path: '/devops',
//         element: <DevopsDevelopment />,
//       },
//       {
//         path: '/fullstack',
//         element: <FullstackDevelopment />,
//       },
//       {
//         path: '/aidevelopment',
//         element: <AiDevelopments />,
//       },

//       {
//         path: 'carts',
//         element: <Carts />,
//       },
//     ],
//   },
// ]);

// ReactDOM.createRoot(document.getElementById('root')).render(
//   <React.StrictMode>
//     <RouterProvider router={router} />
//   </React.StrictMode>,
// );

//////////////////////////////////////  second method //////////

import React, {lazy, Suspense} from 'react';
import ReactDOM from 'react-dom/client';
import {RouterProvider, createBrowserRouter} from 'react-router-dom';
import './App.css';
import './index.css';

const Layout = lazy(() => import('./Layout.jsx'));
const Home = lazy(() => import('./componentes/Pages/Home/Home.jsx'));
const Carts = lazy(() => import('./componentes/Pages/Carts/Carts.jsx'));
const FullstackDevelopment = lazy(() =>
  import('./componentes/Pages/Courses/FullstackDevelopment.jsx'),
);
const AndroidDevelopment = lazy(() =>
  import('./componentes/Pages/Courses/AndroidDevelopment.jsx'),
);
const DevopsDevelopment = lazy(() =>
  import('./componentes/Pages/Courses/DevopsDevelopment.jsx'),
);
const WebDevelopment = lazy(() =>
  import('./componentes/Pages/Courses/WebDevelopment.jsx'),
);
const AiDevelopments = lazy(() =>
  import('./componentes/Pages/Courses/AiDevelopments.jsx'),
);

const router = createBrowserRouter([
  {
    path: '/',
    element: <Layout />,
    children: [
      {
        path: '/',
        element: <Home />,
      },
      {
        path: '/webdevelopment',
        element: <WebDevelopment />,
      },
      {
        path: '/androiddevelopment',
        element: <AndroidDevelopment />,
      },
      {
        path: '/devops',
        element: <DevopsDevelopment />,
      },
      {
        path: '/fullstack',
        element: <FullstackDevelopment />,
      },
      {
        path: '/aidevelopment',
        element: <AiDevelopments />,
      },
      {
        path: 'carts',
        element: <Carts />,
      },
    ],
  },
]);

const App = () => (
  <React.StrictMode>
    <RouterProvider router={router} />
  </React.StrictMode>
);

const rootElement = document.getElementById('root');

ReactDOM.createRoot(rootElement).render(
  <Suspense fallback={<div></div>}>
    <App />
  </Suspense>,
);

//////////////////  second method end ///////////////

// import ReactDOM from 'react-dom/client';
// import App from './App.jsx';

// const rootElement = document.getElementById('root');

// ReactDOM.createRoot(rootElement).render(<App />);
